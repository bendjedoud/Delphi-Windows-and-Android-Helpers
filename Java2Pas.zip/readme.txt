Java2pas
--------

Java2Pas is a converter to create Delphi .pas source code files from android .class or .jar files.

Usage: Java2Pas <.class|.jar> [outputpath]

1.4.0 20140506
- Corrected accidental insertion of local variables into parameter list. 
  NOTE: You should rerun Java2pas on each class with procedures containing
        local variables to have the correct parameter list generated.
- Added automatic uses for JView in Androidapi.JNI.GraphicsContentViewText

1.3.0 20140408

- Added descriptor analysis for static procedures to automatically expand uses list
- Added automatic uses for JCriteria in Androidapi.JNI.Location
- Programm version is written to each generated source file's header

1.2.0 20140331

- Added many keywords to the keyword list to get more reserved words automatically escaped.
- procedures and functions are now also escaped instead of appending "procedure", "function" or "property"
- Changed timestamp in header to yyyymmdd

1.1.0 20140319

- resolved OBO problem with data type shift (Byte -> Char, Integer -> Int64 etc.)
- Instead of appending "param" to smybols representing key words, those are now escaped with "&"


1.0.0 20140314

Initial release
